import { FileText, ArrowRight, Clock, Tag } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";

const notices = [
  { title: "Annual General Meeting 2026 Notice", titleBn: "বার্ষিক সাধারণ সভা ২০২৬ নোটিশ", date: "April 10, 2026", dateBn: "১০ এপ্রিল ২০২৬", category: "Meeting", categoryBn: "সভা", urgent: true },
  { title: "Training on Cloud Computing - Registration Open", titleBn: "ক্লাউড কম্পিউটিং প্রশিক্ষণ - নিবন্ধন চলছে", date: "April 8, 2026", dateBn: "৮ এপ্রিল ২০২৬", category: "Training", categoryBn: "প্রশিক্ষণ", urgent: false },
  { title: "Office Circular: Updated Leave Policy", titleBn: "অফিস সার্কুলার: হালনাগাদ ছুটি নীতি", date: "April 5, 2026", dateBn: "৫ এপ্রিল ২০২৬", category: "Circular", categoryBn: "সার্কুলার", urgent: false },
  { title: "Emergency Meeting: Budget Committee", titleBn: "জরুরি সভা: বাজেট কমিটি", date: "April 3, 2026", dateBn: "৩ এপ্রিল ২০২৬", category: "Urgent", categoryBn: "জরুরি", urgent: true },
];

const NoticesPreview = () => {
  const { t } = useLanguage();

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl gradient-primary flex items-center justify-center">
            <FileText className="h-5 w-5 text-primary-foreground" aria-hidden="true" />
          </div>
          <h3 className="text-2xl font-heading font-bold text-foreground">{t("Latest Notices", "সর্বশেষ নোটিশ")}</h3>
        </div>
        <Link to="/notices">
          <Button variant="ghost" size="sm" className="text-primary">
            {t("View All", "সকল দেখুন")} <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </Link>
      </div>

      <div className="space-y-3">
        {notices.map((notice, i) => (
          <div key={i} className="bg-card rounded-xl p-4 shadow-card hover:shadow-elevated transition-all duration-300 cursor-pointer group border border-border hover:border-primary/30" role="article">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  {notice.urgent && <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-destructive text-destructive-foreground uppercase">{t("Urgent", "জরুরি")}</span>}
                  <span className="flex items-center gap-1 text-xs text-muted-foreground"><Tag className="h-3 w-3" aria-hidden="true" />{t(notice.category, notice.categoryBn)}</span>
                </div>
                <h4 className="font-semibold text-foreground group-hover:text-primary transition-colors text-sm">{t(notice.title, notice.titleBn)}</h4>
              </div>
              <span className="flex items-center gap-1 text-xs text-muted-foreground whitespace-nowrap"><Clock className="h-3 w-3" aria-hidden="true" />{t(notice.date, notice.dateBn)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NoticesPreview;
