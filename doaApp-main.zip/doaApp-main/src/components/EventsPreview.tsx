import { Calendar, MapPin, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";

const events = [
  { title: "Annual General Meeting 2026", titleBn: "বার্ষিক সাধারণ সভা ২০২৬", month: "MAY", day: "15", location: "BCC Bhaban, Dhaka", locationBn: "বিসিসি ভবন, ঢাকা", color: "gradient-primary" },
  { title: "Cybersecurity Workshop", titleBn: "সাইবার নিরাপত্তা কর্মশালা", month: "JUN", day: "01", location: "ICT Tower", locationBn: "আইসিটি টাওয়ার", color: "gradient-accent" },
  { title: "Digital Innovation Summit", titleBn: "ডিজিটাল উদ্ভাবন সম্মেলন", month: "JUL", day: "20", location: "Pan Pacific, Dhaka", locationBn: "প্যান প্যাসিফিক, ঢাকা", color: "gradient-gold" },
];

const EventsPreview = () => {
  const { t } = useLanguage();

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl gradient-accent flex items-center justify-center">
            <Calendar className="h-5 w-5 text-accent-foreground" aria-hidden="true" />
          </div>
          <h3 className="text-2xl font-heading font-bold text-foreground">{t("Upcoming Events", "আসন্ন ইভেন্ট")}</h3>
        </div>
        <Link to="/events">
          <Button variant="ghost" size="sm" className="text-accent">
            {t("View All", "সকল দেখুন")} <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </Link>
      </div>

      <div className="space-y-3">
        {events.map((event, i) => (
          <div key={i} className="bg-card rounded-xl p-4 shadow-card hover:shadow-elevated transition-all duration-300 cursor-pointer group border border-border hover:border-accent/30" role="article">
            <div className="flex items-center gap-4">
              <div className={`${event.color} rounded-xl h-16 w-16 flex flex-col items-center justify-center text-primary-foreground shrink-0`}>
                <span className="text-[10px] font-bold uppercase">{event.month}</span>
                <span className="text-xl font-bold leading-none">{event.day}</span>
              </div>
              <div>
                <h4 className="font-semibold text-foreground group-hover:text-accent transition-colors text-sm">{t(event.title, event.titleBn)}</h4>
                <p className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                  <MapPin className="h-3 w-3" aria-hidden="true" />
                  {t(event.location, event.locationBn)}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EventsPreview;
