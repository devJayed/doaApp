import { Volume2 } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const NewsTicker = () => {
  const { t } = useLanguage();

  const newsItems = [
    t("🔔 Annual General Meeting 2026 scheduled for May 15 at BCC Bhaban", "🔔 বার্ষিক সাধারণ সভা ২০২৬ মে ১৫ তারিখে বিসিসি ভবনে অনুষ্ঠিত হবে"),
    t("📢 New training program on Cybersecurity starting June 1", "📢 সাইবার নিরাপত্তা বিষয়ে নতুন প্রশিক্ষণ কর্মসূচি ১ জুন থেকে শুরু"),
    t("🏆 DOA wins Best Professional Association Award 2025", "🏆 ডিওএ সেরা পেশাদার সমিতি পুরস্কার ২০২৫ জিতেছে"),
    t("📋 Membership renewal deadline extended to April 30, 2026", "📋 সদস্যপদ নবায়নের সময়সীমা ৩০ এপ্রিল ২০২৬ পর্যন্ত বর্ধিত"),
    t("🎉 Digital Bangladesh Celebration - Join us on May 20", "🎉 ডিজিটাল বাংলাদেশ উদযাপন - ২০ মে আমাদের সাথে যোগ দিন"),
  ];

  return (
    <div className="bg-primary text-primary-foreground overflow-hidden" role="marquee" aria-label={t("Latest news", "সর্বশেষ খবর")}>
      <div className="container mx-auto px-4 flex items-center h-10">
        <div className="flex items-center gap-2 shrink-0 pr-4 border-r border-primary-foreground/20">
          <Volume2 className="h-4 w-4" aria-hidden="true" />
          <span className="text-sm font-semibold">{t("Latest", "সর্বশেষ")}</span>
        </div>
        <div className="overflow-hidden ml-4">
          <div className="animate-ticker whitespace-nowrap">
            {newsItems.map((item, i) => (
              <span key={i} className="text-sm mx-8">{item}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewsTicker;
