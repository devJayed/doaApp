import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { FileText, Search, Download, Clock, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLanguage } from "@/contexts/LanguageContext";

const notices = [
  { title: "Annual General Meeting 2026 Notice", titleBn: "বার্ষিক সাধারণ সভা ২০২৬ নোটিশ", date: "April 10, 2026", dateBn: "১০ এপ্রিল ২০২৬", category: "Meeting", categoryBn: "সভা", urgent: true, hasPdf: true },
  { title: "Training on Cloud Computing - Registration Open", titleBn: "ক্লাউড কম্পিউটিং প্রশিক্ষণ - নিবন্ধন চলছে", date: "April 8, 2026", dateBn: "৮ এপ্রিল ২০২৬", category: "Training", categoryBn: "প্রশিক্ষণ", urgent: false, hasPdf: true },
  { title: "Office Circular: Updated Leave Policy", titleBn: "অফিস সার্কুলার: হালনাগাদ ছুটি নীতি", date: "April 5, 2026", dateBn: "৫ এপ্রিল ২০২৬", category: "Circular", categoryBn: "সার্কুলার", urgent: false, hasPdf: true },
  { title: "Emergency Meeting: Budget Committee", titleBn: "জরুরি সভা: বাজেট কমিটি", date: "April 3, 2026", dateBn: "৩ এপ্রিল ২০২৬", category: "Urgent", categoryBn: "জরুরি", urgent: true, hasPdf: false },
  { title: "Workshop on AI in Government Services", titleBn: "সরকারি সেবায় এআই কর্মশালা", date: "March 28, 2026", dateBn: "২৮ মার্চ ২০২৬", category: "Training", categoryBn: "প্রশিক্ষণ", urgent: false, hasPdf: true },
  { title: "New Member Registration Guidelines", titleBn: "নতুন সদস্য নিবন্ধন নির্দেশিকা", date: "March 20, 2026", dateBn: "২০ মার্চ ২০২৬", category: "General", categoryBn: "সাধারণ", urgent: false, hasPdf: true },
  { title: "Quarterly Report Submission Reminder", titleBn: "ত্রৈমাসিক প্রতিবেদন জমা দেওয়ার অনুস্মারক", date: "March 15, 2026", dateBn: "১৫ মার্চ ২০২৬", category: "Circular", categoryBn: "সার্কুলার", urgent: false, hasPdf: false },
  { title: "ICT Day 2026 Celebration Planning", titleBn: "আইসিটি দিবস ২০২৬ উদযাপন পরিকল্পনা", date: "March 10, 2026", dateBn: "১০ মার্চ ২০২৬", category: "General", categoryBn: "সাধারণ", urgent: false, hasPdf: true },
];

const Notices = () => {
  const { t } = useLanguage();

  const categories = [
    { en: "All", bn: "সকল" }, { en: "General", bn: "সাধারণ" }, { en: "Urgent", bn: "জরুরি" },
    { en: "Meeting", bn: "সভা" }, { en: "Training", bn: "প্রশিক্ষণ" }, { en: "Circular", bn: "সার্কুলার" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="gradient-hero py-16 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <FileText className="h-12 w-12 mx-auto mb-4 text-secondary" aria-hidden="true" />
          <h1 className="text-4xl font-heading font-bold">{t("Notice Board", "নোটিশ বোর্ড")}</h1>
          <p className="mt-2 opacity-80">{t("Official notices, circulars, and announcements", "সরকারি নোটিশ, সার্কুলার এবং ঘোষণা")}</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10">
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <Input placeholder={t("Search notices...", "নোটিশ খুঁজুন...")} className="pl-10" aria-label={t("Search notices", "নোটিশ খুঁজুন")} />
          </div>
          <div className="flex gap-2 flex-wrap" role="group" aria-label={t("Filter by category", "বিভাগ অনুযায়ী ফিল্টার")}>
            {categories.map((cat) => (
              <Button key={cat.en} variant={cat.en === "All" ? "default" : "outline"} size="sm" className={cat.en === "All" ? "gradient-primary text-primary-foreground" : ""}>
                {t(cat.en, cat.bn)}
              </Button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          {notices.map((notice, i) => (
            <div key={i} className="bg-card rounded-xl p-5 shadow-card hover:shadow-elevated transition-all border border-border hover:border-primary/30 cursor-pointer group" role="article">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {notice.urgent && <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-destructive text-destructive-foreground uppercase">{t("Urgent", "জরুরি")}</span>}
                    <span className="flex items-center gap-1 text-xs text-muted-foreground"><Tag className="h-3 w-3" aria-hidden="true" />{t(notice.category, notice.categoryBn)}</span>
                  </div>
                  <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">{t(notice.title, notice.titleBn)}</h3>
                </div>
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1 text-xs text-muted-foreground"><Clock className="h-3 w-3" aria-hidden="true" />{t(notice.date, notice.dateBn)}</span>
                  {notice.hasPdf && (
                    <Button size="sm" variant="outline" className="text-primary border-primary/30">
                      <Download className="h-3 w-3 mr-1" /> PDF
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Notices;
