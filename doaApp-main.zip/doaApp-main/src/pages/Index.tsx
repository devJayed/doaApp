import Navbar from "@/components/Navbar";
import NewsTicker from "@/components/NewsTicker";
import HeroSection from "@/components/HeroSection";
import WelcomeSection from "@/components/WelcomeSection";
import NoticesPreview from "@/components/NoticesPreview";
import EventsPreview from "@/components/EventsPreview";
import StatsSection from "@/components/StatsSection";
import GalleryPreview from "@/components/GalleryPreview";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <NewsTicker />
      <HeroSection />
      <WelcomeSection />

      {/* Notices & Events */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <NoticesPreview />
            <EventsPreview />
          </div>
        </div>
      </section>

      <StatsSection />
      <GalleryPreview />
      <Footer />
    </div>
  );
};

export default Index;
