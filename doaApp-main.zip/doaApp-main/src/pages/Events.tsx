import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Calendar, MapPin, Clock, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";

const events = [
  { title: "Annual General Meeting 2026", titleBn: "বার্ষিক সাধারণ সভা ২০২৬", date: "May 15, 2026", dateBn: "১৫ মে ২০২৬", time: "10:00 AM - 4:00 PM", timeBn: "সকাল ১০:০০ - বিকাল ৪:০০", location: "BCC Bhaban, Agargaon, Dhaka", locationBn: "বিসিসি ভবন, আগারগাঁও, ঢাকা", attendees: 120, color: "gradient-primary", status: "Open", statusBn: "খোলা" },
  { title: "Cybersecurity Workshop", titleBn: "সাইবার নিরাপত্তা কর্মশালা", date: "June 1-3, 2026", dateBn: "১-৩ জুন ২০২৬", time: "9:00 AM - 5:00 PM", timeBn: "সকাল ৯:০০ - বিকাল ৫:০০", location: "ICT Tower, Dhaka", locationBn: "আইসিটি টাওয়ার, ঢাকা", attendees: 60, color: "gradient-accent", status: "Open", statusBn: "খোলা" },
  { title: "Digital Innovation Summit", titleBn: "ডিজিটাল উদ্ভাবন সম্মেলন", date: "July 20, 2026", dateBn: "২০ জুলাই ২০২৬", time: "9:30 AM - 6:00 PM", timeBn: "সকাল ৯:৩০ - সন্ধ্যা ৬:০০", location: "Pan Pacific Sonargaon, Dhaka", locationBn: "প্যান প্যাসিফিক সোনারগাঁও, ঢাকা", attendees: 200, color: "gradient-gold", status: "Coming Soon", statusBn: "শীঘ্রই আসছে" },
  { title: "AI in Government Services Seminar", titleBn: "সরকারি সেবায় এআই সেমিনার", date: "August 10, 2026", dateBn: "১০ আগস্ট ২০২৬", time: "2:00 PM - 5:00 PM", timeBn: "দুপুর ২:০০ - বিকাল ৫:০০", location: "BCC Bhaban, Agargaon", locationBn: "বিসিসি ভবন, আগারগাঁও", attendees: 80, color: "gradient-primary", status: "Coming Soon", statusBn: "শীঘ্রই আসছে" },
  { title: "Team Building Retreat 2026", titleBn: "টিম বিল্ডিং রিট্রিট ২০২৬", date: "September 5-6, 2026", dateBn: "৫-৬ সেপ্টেম্বর ২০২৬", time: "All Day", timeBn: "সারাদিন", location: "Cox's Bazar", locationBn: "কক্সবাজার", attendees: 50, color: "gradient-accent", status: "Coming Soon", statusBn: "শীঘ্রই আসছে" },
];

const Events = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="gradient-hero py-16 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <Calendar className="h-12 w-12 mx-auto mb-4 text-secondary" aria-hidden="true" />
          <h1 className="text-4xl font-heading font-bold">{t("Events & Activities", "ইভেন্ট ও কার্যক্রম")}</h1>
          <p className="mt-2 opacity-80">{t("Stay updated with our upcoming events", "আমাদের আসন্ন ইভেন্টগুলি সম্পর্কে আপডেট থাকুন")}</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {events.map((event, i) => (
            <div key={i} className="bg-card rounded-2xl shadow-card hover:shadow-elevated transition-all border border-border overflow-hidden group" role="article">
              <div className={`${event.color} p-6 text-primary-foreground`}>
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-heading font-bold">{t(event.title, event.titleBn)}</h3>
                  <span className="px-3 py-1 rounded-full bg-card/20 text-xs font-semibold">{t(event.status, event.statusBn)}</span>
                </div>
              </div>
              <div className="p-6 space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4 text-primary" aria-hidden="true" />
                  {t(event.date, event.dateBn)}
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4 text-primary" aria-hidden="true" />
                  {t(event.time, event.timeBn)}
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4 text-primary" aria-hidden="true" />
                  {t(event.location, event.locationBn)}
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="h-4 w-4 text-primary" aria-hidden="true" />
                  {event.attendees} {t("expected attendees", "প্রত্যাশিত অংশগ্রহণকারী")}
                </div>
                <Button className={`w-full mt-2 ${event.status === "Open" ? "gradient-primary text-primary-foreground" : ""}`} disabled={event.status !== "Open"}>
                  {event.status === "Open" ? t("Register Now", "এখনই নিবন্ধন করুন") : t("Coming Soon", "শীঘ্রই আসছে")}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Events;
